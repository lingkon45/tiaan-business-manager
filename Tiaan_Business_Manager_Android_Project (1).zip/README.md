# Tiaan Business Manager — Android project starter

## Configured business structure
- Tiaan Tech (electronics)
- Tiaan Mart
- China Bridge
- Separate business reports plus an all-business dashboard
- Product inventory, sales, expenses, estimated profit, English cash memos
- Cash and digital-payment recording; amounts in Bangladeshi taka (BDT)

## What is included
This is a starter Android Studio project with a simple WebView-based business app and local-device storage. It can be built into a **debug APK** using Android Studio.

## Build the APK
1. Download and extract this ZIP on a Windows computer.
2. Install Android Studio from the official Android developer website.
3. In Android Studio, choose **Open** and select the extracted `Tiaan_Business_Manager` project folder.
4. Allow Gradle sync and install the SDK components Android Studio requests.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build completes, choose **Locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone, open it, and approve installation if Android asks.

## Cloud synchronization is NOT yet configured
The included starter stores records in local app storage on one device. A cloud backend and authentication have to be configured before the app can safely sync data. A practical Firebase setup is:

1. Create a Firebase project in the Firebase Console.
2. Register the Android app with package name `com.tiaantech.businessmanager`.
3. Add Firebase Authentication and enable one sign-in method for the owner.
4. Create a Cloud Firestore database.
5. Configure restrictive Firestore security rules so only the authenticated owner can read/write the three business records. Never use open/public rules.
6. Add the Firebase Android SDK/configuration to the Android project and implement syncing of products, sales, expenses and memo records.
7. Test sign-in, offline behavior, duplicate writes, data restore and access restrictions before entering real business data.
8. Rebuild and install a new APK after cloud integration.

**Do not treat the current starter as a cloud-synced app.** It does not yet contain Firebase credentials, cloud syncing, authentication, or an automated cloud backup. Those steps require your Firebase project configuration and code integration. Do not share private service-account keys or passwords in chat.

## Accounting notes
The profit metric is a basic estimate: recorded sales revenue minus recorded cost of goods sold and entered expenses. It is not a substitute for a verified accounting system. Back up exported JSON files regularly; local browser storage can be lost if app data is cleared or the app is uninstalled.

## Build from your Android phone using GitHub Actions (no local compiler)
The ZIP includes `.github/workflows/android.yml` to build a debug APK on GitHub's hosted runner. GitHub requires you to create an account/repository and upload the project files; the workflow then builds the APK remotely.

1. Download and extract this ZIP on your phone using a file manager that supports ZIP extraction.
2. In your browser, sign in to GitHub and create a **private** repository named `tiaan-business-manager`.
3. Use the repository's **Add file → Upload files** feature to upload the extracted project files and folders, including `.github/workflows/android.yml`. Folder upload support can vary by mobile browser; if this is difficult, the alternative is AndroidIDE, but it is more technical.
4. Commit the uploaded files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build Android APK**. If prompted, enable workflows, then press **Run workflow**.
6. Wait for the workflow to finish successfully. Open the completed run and download the `Tiaan-Business-Manager-debug-APK` artifact. Extract the downloaded artifact ZIP to obtain `app-debug.apk`.
7. Tap the APK and follow Android's install prompts. Only install the APK from your own repository/workflow.
8. This builds the current starter only. It does **not** add cloud synchronization.

GitHub Actions availability, usage limits, and UI labels can change. Keep the repository private because the project concerns business operations.

## Cloud sync remains a separate development task
Do not upload Firebase service-account keys or passwords. Firebase client configuration is not the same as a server private key. Cloud sign-in, owner-only Firestore rules, and synchronization logic still need to be implemented and tested before using real data.
